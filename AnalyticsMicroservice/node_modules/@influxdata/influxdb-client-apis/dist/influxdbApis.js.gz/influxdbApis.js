var influxdbApis = (function (exports) {
    'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function base64(value) {
        return typeof btoa === 'function' // browser (window,worker) environment
            ? btoa(value)
            : Buffer.from(value, 'binary').toString('base64');
    }
    /**
     * Base class for all apis.
     */
    var APIBase = /** @class */ (function () {
        /**
         * Initializes transport to communicate with InfluxDB.
         * @param influxDB - the main InfluxDB client object
         */
        function APIBase(influxDB) {
            if (!influxDB)
                throw new Error('No influxDB supplied!');
            if (!influxDB.transport)
                throw new Error('No transport supplied!');
            this.transport = influxDB.transport;
        }
        APIBase.prototype.queryString = function (request, params) {
            if (request && params) {
                return params.reduce(function (acc, key) {
                    var val = request[key];
                    if (val !== undefined && val !== null) {
                        acc += acc ? '&' : '?';
                        acc += encodeURIComponent(key) + '=' + encodeURIComponent(String(val));
                    }
                    return acc;
                }, '');
            }
            else {
                return '';
            }
        };
        APIBase.prototype.request = function (method, path, request, requestOptions, mediaType) {
            if (request === void 0) { request = {}; }
            var sendOptions = __assign(__assign({}, requestOptions), { method: method });
            if (mediaType) {
                (sendOptions.headers || (sendOptions.headers = {}))['content-type'] = mediaType;
            }
            if (request.auth) {
                var value = "".concat(request.auth.user, ":").concat(request.auth.password);
                (sendOptions.headers || (sendOptions.headers = {}))['authorization'] = "Basic ".concat(base64(value));
            }
            return this.transport.request(path, request.body ? request.body : '', sendOptions, requestOptions === null || requestOptions === void 0 ? void 0 : requestOptions.responseStarted);
        };
        return APIBase;
    }());

    /**
     * Root API
     */
    var RootAPI = /** @class */ (function () {
        /**
         * Creates RootAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function RootAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all top level routes.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetRoutes }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RootAPI.prototype.getRoutes = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/", request, requestOptions);
        };
        return RootAPI;
    }());

    /**
     * Authorizations API
     */
    var AuthorizationsAPI = /** @class */ (function () {
        /**
         * Creates AuthorizationsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function AuthorizationsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all authorizations.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetAuthorizations }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.getAuthorizations = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/authorizations".concat(this.base.queryString(request, [
                'userID',
                'user',
                'orgID',
                'org',
            ])), request, requestOptions);
        };
        /**
         * Create an authorization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostAuthorizations }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.postAuthorizations = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/authorizations", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve an authorization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.getAuthorizationsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/authorizations/".concat(request.authID), request, requestOptions);
        };
        /**
         * Update an authorization to be active or inactive.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.patchAuthorizationsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/authorizations/".concat(request.authID), request, requestOptions, 'application/json');
        };
        /**
         * Delete an authorization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.deleteAuthorizationsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/authorizations/".concat(request.authID), request, requestOptions);
        };
        return AuthorizationsAPI;
    }());

    /**
     * Backup API
     */
    var BackupAPI = /** @class */ (function () {
        /**
         * Creates BackupAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function BackupAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Download snapshot of metadata stored in the server's embedded KV store. Should not be used in versions greater than 2.1.x, as it doesn't include metadata stored in embedded SQL.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetBackupKV }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BackupAPI.prototype.getBackupKV = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/backup/kv", request, requestOptions);
        };
        /**
         * Download snapshot of all metadata in the server.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetBackupMetadata }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BackupAPI.prototype.getBackupMetadata = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/backup/metadata", request, requestOptions);
        };
        /**
         * Download snapshot of all TSM data in a shard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetBackupShardId }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BackupAPI.prototype.getBackupShardId = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/backup/shards/".concat(request.shardID).concat(this.base.queryString(request, ['since'])), request, requestOptions);
        };
        return BackupAPI;
    }());

    /**
     * Buckets API
     */
    var BucketsAPI = /** @class */ (function () {
        /**
         * Creates BucketsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function BucketsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all buckets.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetBuckets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBuckets = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets".concat(this.base.queryString(request, [
                'offset',
                'limit',
                'after',
                'org',
                'orgID',
                'name',
                'id',
            ])), request, requestOptions);
        };
        /**
         * Create a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostBuckets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.postBuckets = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/buckets", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetBucketsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBucketsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets/".concat(request.bucketID), request, requestOptions);
        };
        /**
         * Update a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchBucketsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.patchBucketsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/buckets/".concat(request.bucketID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteBucketsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.deleteBucketsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/buckets/".concat(request.bucketID), request, requestOptions);
        };
        /**
         * List all labels for a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetBucketsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBucketsIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets/".concat(request.bucketID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostBucketsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.postBucketsIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/buckets/".concat(request.bucketID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteBucketsIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.deleteBucketsIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/buckets/".concat(request.bucketID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        /**
         * List all users with member privileges for a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetBucketsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBucketsIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets/".concat(request.bucketID, "/members"), request, requestOptions);
        };
        /**
         * Add a member to a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostBucketsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.postBucketsIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/buckets/".concat(request.bucketID, "/members"), request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteBucketsIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.deleteBucketsIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/buckets/".concat(request.bucketID, "/members/").concat(request.userID), request, requestOptions);
        };
        /**
         * List all owners of a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetBucketsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBucketsIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets/".concat(request.bucketID, "/owners"), request, requestOptions);
        };
        /**
         * Add an owner to a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostBucketsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.postBucketsIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/buckets/".concat(request.bucketID, "/owners"), request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteBucketsIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.deleteBucketsIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/buckets/".concat(request.bucketID, "/owners/").concat(request.userID), request, requestOptions);
        };
        return BucketsAPI;
    }());

    /**
     * Checks API
     */
    var ChecksAPI = /** @class */ (function () {
        /**
         * Creates ChecksAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ChecksAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all checks.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetChecks }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.getChecks = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/checks".concat(this.base.queryString(request, [
                'offset',
                'limit',
                'orgID',
            ])), request, requestOptions);
        };
        /**
         * Add new check.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/CreateCheck }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.createCheck = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/checks", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a check.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetChecksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.getChecksID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/checks/".concat(request.checkID), request, requestOptions);
        };
        /**
         * Update a check.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PutChecksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.putChecksID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/checks/".concat(request.checkID), request, requestOptions, 'application/json');
        };
        /**
         * Update a check.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchChecksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.patchChecksID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/checks/".concat(request.checkID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a check.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteChecksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.deleteChecksID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/checks/".concat(request.checkID), request, requestOptions);
        };
        /**
         * List all labels for a check.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetChecksIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.getChecksIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/checks/".concat(request.checkID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a check.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostChecksIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.postChecksIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/checks/".concat(request.checkID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete label from a check.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteChecksIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.deleteChecksIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/checks/".concat(request.checkID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        /**
         * Retrieve a check query.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetChecksIDQuery }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.getChecksIDQuery = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/checks/".concat(request.checkID, "/query"), request, requestOptions);
        };
        return ChecksAPI;
    }());

    /**
     * Config API
     */
    var ConfigAPI = /** @class */ (function () {
        /**
         * Creates ConfigAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ConfigAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Retrieve runtime configuration.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetConfig }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ConfigAPI.prototype.getConfig = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/config", request, requestOptions);
        };
        return ConfigAPI;
    }());

    /**
     * Dashboards API
     */
    var DashboardsAPI = /** @class */ (function () {
        /**
         * Creates DashboardsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function DashboardsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Retrieve a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDashboardsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/".concat(request.dashboardID).concat(this.base.queryString(request, ['include'])), request, requestOptions);
        };
        /**
         * Update a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchDashboardsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.patchDashboardsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/dashboards/".concat(request.dashboardID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteDashboardsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/".concat(request.dashboardID), request, requestOptions);
        };
        /**
         * Create a dashboard cell.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostDashboardsIDCells }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboardsIDCells = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards/".concat(request.dashboardID, "/cells"), request, requestOptions, 'application/json');
        };
        /**
         * Replace cells in a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PutDashboardsIDCells }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.putDashboardsIDCells = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/dashboards/".concat(request.dashboardID, "/cells"), request, requestOptions, 'application/json');
        };
        /**
         * Update the non-positional information related to a cell.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchDashboardsIDCellsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.patchDashboardsIDCellsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/dashboards/".concat(request.dashboardID, "/cells/").concat(request.cellID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a dashboard cell.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteDashboardsIDCellsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsIDCellsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/".concat(request.dashboardID, "/cells/").concat(request.cellID), request, requestOptions);
        };
        /**
         * Retrieve the view for a cell.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDashboardsIDCellsIDView }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsIDCellsIDView = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/".concat(request.dashboardID, "/cells/").concat(request.cellID, "/view"), request, requestOptions);
        };
        /**
         * Update the view for a cell.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchDashboardsIDCellsIDView }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.patchDashboardsIDCellsIDView = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/dashboards/".concat(request.dashboardID, "/cells/").concat(request.cellID, "/view"), request, requestOptions, 'application/json');
        };
        /**
         * List all labels for a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDashboardsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/".concat(request.dashboardID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostDashboardsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboardsIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards/".concat(request.dashboardID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteDashboardsIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/".concat(request.dashboardID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        /**
         * List all dashboard members.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDashboardsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/".concat(request.dashboardID, "/members"), request, requestOptions);
        };
        /**
         * Add a member to a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostDashboardsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboardsIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards/".concat(request.dashboardID, "/members"), request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteDashboardsIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/".concat(request.dashboardID, "/members/").concat(request.userID), request, requestOptions);
        };
        /**
         * List all dashboard owners.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDashboardsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/".concat(request.dashboardID, "/owners"), request, requestOptions);
        };
        /**
         * Add an owner to a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostDashboardsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboardsIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards/".concat(request.dashboardID, "/owners"), request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteDashboardsIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/".concat(request.dashboardID, "/owners/").concat(request.userID), request, requestOptions);
        };
        /**
         * List all dashboards.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDashboards }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboards = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards".concat(this.base.queryString(request, [
                'offset',
                'limit',
                'descending',
                'owner',
                'sortBy',
                'id',
                'orgID',
                'org',
            ])), request, requestOptions);
        };
        /**
         * Create a dashboard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostDashboards }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboards = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards", request, requestOptions, 'application/json');
        };
        return DashboardsAPI;
    }());

    /**
     * Dbrps API
     */
    var DbrpsAPI = /** @class */ (function () {
        /**
         * Creates DbrpsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function DbrpsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List database retention policy mappings.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDBRPs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.getDBRPs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dbrps".concat(this.base.queryString(request, [
                'orgID',
                'org',
                'id',
                'bucketID',
                'default',
                'db',
                'rp',
            ])), request, requestOptions);
        };
        /**
         * Add a database retention policy mapping.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostDBRP }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.postDBRP = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dbrps", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a database retention policy mapping.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDBRPsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.getDBRPsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dbrps/".concat(request.dbrpID).concat(this.base.queryString(request, [
                'orgID',
                'org',
            ])), request, requestOptions);
        };
        /**
         * Update a database retention policy mapping.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchDBRPID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.patchDBRPID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/dbrps/".concat(request.dbrpID).concat(this.base.queryString(request, [
                'orgID',
                'org',
            ])), request, requestOptions, 'application/json');
        };
        /**
         * Delete a database retention policy.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteDBRPID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.deleteDBRPID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dbrps/".concat(request.dbrpID).concat(this.base.queryString(request, [
                'orgID',
                'org',
            ])), request, requestOptions);
        };
        return DbrpsAPI;
    }());

    /**
     * Debug API
     */
    var DebugAPI = /** @class */ (function () {
        /**
         * Creates DebugAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function DebugAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Retrieve all runtime profiles.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofAllProfiles }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofAllProfiles = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/all".concat(this.base.queryString(request, ['cpu'])), request, requestOptions);
        };
        /**
         * Retrieve the memory allocations runtime profile.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofAllocs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofAllocs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/allocs".concat(this.base.queryString(request, [
                'debug',
                'seconds',
            ])), request, requestOptions);
        };
        /**
         * Retrieve the block runtime profile.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofBlock }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofBlock = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/block".concat(this.base.queryString(request, [
                'debug',
                'seconds',
            ])), request, requestOptions);
        };
        /**
         * Retrieve the command line invocation.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofCmdline }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofCmdline = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/cmdline", request, requestOptions);
        };
        /**
         * Retrieve the goroutines runtime profile.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofGoroutine }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofGoroutine = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/goroutine".concat(this.base.queryString(request, [
                'debug',
                'seconds',
            ])), request, requestOptions);
        };
        /**
         * Retrieve the heap runtime profile.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofHeap }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofHeap = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/heap".concat(this.base.queryString(request, [
                'debug',
                'seconds',
                'gc',
            ])), request, requestOptions);
        };
        /**
         * Retrieve the mutual exclusion (mutex) runtime profile.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofMutex }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofMutex = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/mutex".concat(this.base.queryString(request, [
                'debug',
                'seconds',
            ])), request, requestOptions);
        };
        /**
         * Retrieve the CPU runtime profile.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofProfile }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofProfile = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/profile".concat(this.base.queryString(request, [
                'seconds',
            ])), request, requestOptions);
        };
        /**
         * Retrieve the threadcreate runtime profile.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofThreadCreate }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofThreadCreate = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/threadcreate".concat(this.base.queryString(request, [
                'debug',
                'seconds',
            ])), request, requestOptions);
        };
        /**
         * Retrieve the runtime execution trace.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetDebugPprofTrace }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DebugAPI.prototype.getDebugPprofTrace = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/debug/pprof/trace".concat(this.base.queryString(request, ['seconds'])), request, requestOptions);
        };
        return DebugAPI;
    }());

    /**
     * Delete API
     */
    var DeleteAPI = /** @class */ (function () {
        /**
         * Creates DeleteAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function DeleteAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Delete data.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostDelete }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DeleteAPI.prototype.postDelete = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/delete".concat(this.base.queryString(request, [
                'org',
                'bucket',
                'orgID',
                'bucketID',
            ])), request, requestOptions, 'application/json');
        };
        return DeleteAPI;
    }());

    /**
     * Flags API
     */
    var FlagsAPI = /** @class */ (function () {
        /**
         * Creates FlagsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function FlagsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Return the feature flags for the currently authenticated user.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetFlags }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        FlagsAPI.prototype.getFlags = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/flags", request, requestOptions);
        };
        return FlagsAPI;
    }());

    /**
     * Health API
     */
    var HealthAPI = /** @class */ (function () {
        /**
         * Creates HealthAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function HealthAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Retrieve the health of the instance.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetHealth }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        HealthAPI.prototype.getHealth = function (request, requestOptions) {
            return this.base.request('GET', "/health", request, requestOptions);
        };
        return HealthAPI;
    }());

    /**
     * Labels API
     */
    var LabelsAPI = /** @class */ (function () {
        /**
         * Creates LabelsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function LabelsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all labels.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.getLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/labels".concat(this.base.queryString(request, ['orgID'])), request, requestOptions);
        };
        /**
         * Create a label.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.postLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/labels", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a label.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.getLabelsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/labels/".concat(request.labelID), request, requestOptions);
        };
        /**
         * Update a label.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.patchLabelsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/labels/".concat(request.labelID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a label.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.deleteLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/labels/".concat(request.labelID), request, requestOptions);
        };
        return LabelsAPI;
    }());

    /**
     * Legacy API
     */
    var LegacyAPI = /** @class */ (function () {
        /**
         * Creates LegacyAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function LegacyAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all legacy authorizations.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetLegacyAuthorizations }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LegacyAPI.prototype.getLegacyAuthorizations = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/legacy/authorizations".concat(this.base.queryString(request, [
                'userID',
                'user',
                'orgID',
                'org',
                'token',
                'authID',
            ])), request, requestOptions);
        };
        /**
         * Create a legacy authorization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostLegacyAuthorizations }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LegacyAPI.prototype.postLegacyAuthorizations = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/legacy/authorizations", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a legacy authorization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetLegacyAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LegacyAPI.prototype.getLegacyAuthorizationsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/legacy/authorizations/".concat(request.authID), request, requestOptions);
        };
        /**
         * Update a legacy authorization to be active or inactive.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchLegacyAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LegacyAPI.prototype.patchLegacyAuthorizationsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/legacy/authorizations/".concat(request.authID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a legacy authorization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteLegacyAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LegacyAPI.prototype.deleteLegacyAuthorizationsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/legacy/authorizations/".concat(request.authID), request, requestOptions);
        };
        /**
         * Set a legacy authorization password.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostLegacyAuthorizationsIDPassword }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LegacyAPI.prototype.postLegacyAuthorizationsIDPassword = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/legacy/authorizations/".concat(request.authID, "/password"), request, requestOptions, 'application/json');
        };
        return LegacyAPI;
    }());

    /**
     * Me API
     */
    var MeAPI = /** @class */ (function () {
        /**
         * Creates MeAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function MeAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Retrieve the currently authenticated user.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetMe }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        MeAPI.prototype.getMe = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/me", request, requestOptions);
        };
        /**
         * Update a password.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PutMePassword }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        MeAPI.prototype.putMePassword = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/me/password", request, requestOptions, 'application/json');
        };
        return MeAPI;
    }());

    /**
     * Metrics API
     */
    var MetricsAPI = /** @class */ (function () {
        /**
         * Creates MetricsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function MetricsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Retrieve workload performance metrics.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetMetrics }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        MetricsAPI.prototype.getMetrics = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/metrics", request, requestOptions);
        };
        return MetricsAPI;
    }());

    /**
     * NotificationEndpoints API
     */
    var NotificationEndpointsAPI = /** @class */ (function () {
        /**
         * Creates NotificationEndpointsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function NotificationEndpointsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all notification endpoints.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetNotificationEndpoints }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.getNotificationEndpoints = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationEndpoints".concat(this.base.queryString(request, [
                'offset',
                'limit',
                'orgID',
            ])), request, requestOptions);
        };
        /**
         * Add a notification endpoint.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/CreateNotificationEndpoint }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.createNotificationEndpoint = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/notificationEndpoints", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a notification endpoint.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetNotificationEndpointsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.getNotificationEndpointsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationEndpoints/".concat(request.endpointID), request, requestOptions);
        };
        /**
         * Update a notification endpoint.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PutNotificationEndpointsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.putNotificationEndpointsID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/notificationEndpoints/".concat(request.endpointID), request, requestOptions, 'application/json');
        };
        /**
         * Update a notification endpoint.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchNotificationEndpointsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.patchNotificationEndpointsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/notificationEndpoints/".concat(request.endpointID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a notification endpoint.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteNotificationEndpointsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.deleteNotificationEndpointsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/notificationEndpoints/".concat(request.endpointID), request, requestOptions);
        };
        /**
         * List all labels for a notification endpoint.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetNotificationEndpointsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.getNotificationEndpointsIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationEndpoints/".concat(request.endpointID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a notification endpoint.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostNotificationEndpointIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.postNotificationEndpointIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/notificationEndpoints/".concat(request.endpointID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a notification endpoint.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteNotificationEndpointsIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.deleteNotificationEndpointsIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/notificationEndpoints/".concat(request.endpointID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        return NotificationEndpointsAPI;
    }());

    /**
     * NotificationRules API
     */
    var NotificationRulesAPI = /** @class */ (function () {
        /**
         * Creates NotificationRulesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function NotificationRulesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all notification rules.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetNotificationRules }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.getNotificationRules = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationRules".concat(this.base.queryString(request, [
                'offset',
                'limit',
                'orgID',
                'checkID',
                'tag',
            ])), request, requestOptions);
        };
        /**
         * Add a notification rule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/CreateNotificationRule }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.createNotificationRule = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/notificationRules", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a notification rule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetNotificationRulesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.getNotificationRulesID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationRules/".concat(request.ruleID), request, requestOptions);
        };
        /**
         * Update a notification rule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PutNotificationRulesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.putNotificationRulesID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/notificationRules/".concat(request.ruleID), request, requestOptions, 'application/json');
        };
        /**
         * Update a notification rule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchNotificationRulesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.patchNotificationRulesID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/notificationRules/".concat(request.ruleID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a notification rule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteNotificationRulesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.deleteNotificationRulesID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/notificationRules/".concat(request.ruleID), request, requestOptions);
        };
        /**
         * List all labels for a notification rule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetNotificationRulesIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.getNotificationRulesIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationRules/".concat(request.ruleID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a notification rule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostNotificationRuleIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.postNotificationRuleIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/notificationRules/".concat(request.ruleID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete label from a notification rule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteNotificationRulesIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.deleteNotificationRulesIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/notificationRules/".concat(request.ruleID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        /**
         * Retrieve a notification rule query.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetNotificationRulesIDQuery }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.getNotificationRulesIDQuery = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationRules/".concat(request.ruleID, "/query"), request, requestOptions);
        };
        return NotificationRulesAPI;
    }());

    /**
     * Orgs API
     */
    var OrgsAPI = /** @class */ (function () {
        /**
         * Creates OrgsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function OrgsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all organizations.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetOrgs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs".concat(this.base.queryString(request, [
                'offset',
                'limit',
                'descending',
                'org',
                'orgID',
                'userID',
            ])), request, requestOptions);
        };
        /**
         * Create an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostOrgs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.postOrgs = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/orgs", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetOrgsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs/".concat(request.orgID), request, requestOptions);
        };
        /**
         * Update an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchOrgsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.patchOrgsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/orgs/".concat(request.orgID), request, requestOptions, 'application/json');
        };
        /**
         * Delete an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteOrgsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.deleteOrgsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/orgs/".concat(request.orgID), request, requestOptions);
        };
        /**
         * List all secret keys for an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetOrgsIDSecrets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgsIDSecrets = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs/".concat(request.orgID, "/secrets"), request, requestOptions);
        };
        /**
         * Update secrets in an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchOrgsIDSecrets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.patchOrgsIDSecrets = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/orgs/".concat(request.orgID, "/secrets"), request, requestOptions, 'application/json');
        };
        /**
         * List all members of an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetOrgsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgsIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs/".concat(request.orgID, "/members"), request, requestOptions);
        };
        /**
         * Add a member to an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostOrgsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.postOrgsIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/orgs/".concat(request.orgID, "/members"), request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteOrgsIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.deleteOrgsIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/orgs/".concat(request.orgID, "/members/").concat(request.userID), request, requestOptions);
        };
        /**
         * List all owners of an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetOrgsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgsIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs/".concat(request.orgID, "/owners"), request, requestOptions);
        };
        /**
         * Add an owner to an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostOrgsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.postOrgsIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/orgs/".concat(request.orgID, "/owners"), request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteOrgsIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.deleteOrgsIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/orgs/".concat(request.orgID, "/owners/").concat(request.userID), request, requestOptions);
        };
        /**
         * Delete secrets from an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostOrgsIDSecrets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.postOrgsIDSecrets = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/orgs/".concat(request.orgID, "/secrets/delete"), request, requestOptions, 'application/json');
        };
        /**
         * Delete a secret from an organization.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteOrgsIDSecretsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.deleteOrgsIDSecretsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/orgs/".concat(request.orgID, "/secrets/").concat(request.secretID), request, requestOptions);
        };
        return OrgsAPI;
    }());

    /**
     * Ping API
     */
    var PingAPI = /** @class */ (function () {
        /**
         * Creates PingAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function PingAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get the status and version of the instance.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetPing }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        PingAPI.prototype.getPing = function (request, requestOptions) {
            return this.base.request('GET', "/ping", request, requestOptions);
        };
        return PingAPI;
    }());

    /**
     * Query API
     */
    var QueryAPI = /** @class */ (function () {
        /**
         * Creates QueryAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function QueryAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Generate an Abstract Syntax Tree (AST) from a query.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostQueryAst }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.postQueryAst = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/query/ast", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve query suggestions.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetQuerySuggestions }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.getQuerySuggestions = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/query/suggestions", request, requestOptions);
        };
        /**
         * Retrieve query suggestions for a branching suggestion.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetQuerySuggestionsName }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.getQuerySuggestionsName = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/query/suggestions/".concat(request.name), request, requestOptions);
        };
        /**
         * Analyze a Flux query.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostQueryAnalyze }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.postQueryAnalyze = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/query/analyze", request, requestOptions, 'application/json');
        };
        /**
         * Query data.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostQuery }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.postQuery = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/query".concat(this.base.queryString(request, ['org', 'orgID'])), request, requestOptions, 'application/json');
        };
        return QueryAPI;
    }());

    /**
     * Ready API
     */
    var ReadyAPI = /** @class */ (function () {
        /**
         * Creates ReadyAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ReadyAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get the readiness of an instance at startup.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetReady }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ReadyAPI.prototype.getReady = function (request, requestOptions) {
            return this.base.request('GET', "/ready", request, requestOptions);
        };
        return ReadyAPI;
    }());

    /**
     * Remotes API
     */
    var RemotesAPI = /** @class */ (function () {
        /**
         * Creates RemotesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function RemotesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all remote connections.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetRemoteConnections }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RemotesAPI.prototype.getRemoteConnections = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/remotes".concat(this.base.queryString(request, [
                'orgID',
                'name',
                'remoteURL',
            ])), request, requestOptions);
        };
        /**
         * Register a new remote connection.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostRemoteConnection }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RemotesAPI.prototype.postRemoteConnection = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/remotes", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a remote connection.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetRemoteConnectionByID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RemotesAPI.prototype.getRemoteConnectionByID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/remotes/".concat(request.remoteID), request, requestOptions);
        };
        /**
         * Update a remote connection.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchRemoteConnectionByID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RemotesAPI.prototype.patchRemoteConnectionByID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/remotes/".concat(request.remoteID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a remote connection.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteRemoteConnectionByID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RemotesAPI.prototype.deleteRemoteConnectionByID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/remotes/".concat(request.remoteID), request, requestOptions);
        };
        return RemotesAPI;
    }());

    /**
     * Replications API
     */
    var ReplicationsAPI = /** @class */ (function () {
        /**
         * Creates ReplicationsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ReplicationsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all replications.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetReplications }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ReplicationsAPI.prototype.getReplications = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/replications".concat(this.base.queryString(request, [
                'orgID',
                'name',
                'remoteID',
                'localBucketID',
            ])), request, requestOptions);
        };
        /**
         * Register a new replication.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostReplication }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ReplicationsAPI.prototype.postReplication = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/replications".concat(this.base.queryString(request, ['validate'])), request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a replication.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetReplicationByID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ReplicationsAPI.prototype.getReplicationByID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/replications/".concat(request.replicationID), request, requestOptions);
        };
        /**
         * Update a replication.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchReplicationByID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ReplicationsAPI.prototype.patchReplicationByID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/replications/".concat(request.replicationID).concat(this.base.queryString(request, ['validate'])), request, requestOptions, 'application/json');
        };
        /**
         * Delete a replication.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteReplicationByID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ReplicationsAPI.prototype.deleteReplicationByID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/replications/".concat(request.replicationID), request, requestOptions);
        };
        /**
         * Validate a replication.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostValidateReplicationByID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ReplicationsAPI.prototype.postValidateReplicationByID = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/replications/".concat(request.replicationID, "/validate"), request, requestOptions);
        };
        return ReplicationsAPI;
    }());

    /**
     * Resources API
     */
    var ResourcesAPI = /** @class */ (function () {
        /**
         * Creates ResourcesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ResourcesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all known resources.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetResources }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ResourcesAPI.prototype.getResources = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/resources", request, requestOptions);
        };
        return ResourcesAPI;
    }());

    /**
     * Restore API
     */
    var RestoreAPI = /** @class */ (function () {
        /**
         * Creates RestoreAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function RestoreAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Overwrite the embedded KV store on the server with a backed-up snapshot.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostRestoreKV }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RestoreAPI.prototype.postRestoreKV = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/restore/kv", request, requestOptions, 'text/plain');
        };
        /**
         * Overwrite the embedded SQL store on the server with a backed-up snapshot.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostRestoreSQL }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RestoreAPI.prototype.postRestoreSQL = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/restore/sql", request, requestOptions, 'text/plain');
        };
        /**
         * Overwrite storage metadata for a bucket with shard info from a backup.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostRestoreBucketID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RestoreAPI.prototype.postRestoreBucketID = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/restore/bucket/".concat(request.bucketID), request, requestOptions, 'text/plain');
        };
        /**
         * Create a new bucket pre-seeded with shard info from a backup.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostRestoreBucketMetadata }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RestoreAPI.prototype.postRestoreBucketMetadata = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/restore/bucketMetadata", request, requestOptions, 'application/json');
        };
        /**
         * Restore a TSM snapshot into a shard.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostRestoreShardId }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RestoreAPI.prototype.postRestoreShardId = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/restore/shards/".concat(request.shardID), request, requestOptions, 'text/plain');
        };
        return RestoreAPI;
    }());

    /**
     * Scrapers API
     */
    var ScrapersAPI = /** @class */ (function () {
        /**
         * Creates ScrapersAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ScrapersAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all scraper targets.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetScrapers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers".concat(this.base.queryString(request, [
                'name',
                'id',
                'orgID',
                'org',
            ])), request, requestOptions);
        };
        /**
         * Create a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostScrapers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.postScrapers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scrapers", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetScrapersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapersID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers/".concat(request.scraperTargetID), request, requestOptions);
        };
        /**
         * Update a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchScrapersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.patchScrapersID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/scrapers/".concat(request.scraperTargetID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteScrapersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.deleteScrapersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scrapers/".concat(request.scraperTargetID), request, requestOptions);
        };
        /**
         * List all labels for a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetScrapersIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapersIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers/".concat(request.scraperTargetID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostScrapersIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.postScrapersIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scrapers/".concat(request.scraperTargetID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteScrapersIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.deleteScrapersIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scrapers/".concat(request.scraperTargetID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        /**
         * List all users with member privileges for a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetScrapersIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapersIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers/".concat(request.scraperTargetID, "/members"), request, requestOptions);
        };
        /**
         * Add a member to a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostScrapersIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.postScrapersIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scrapers/".concat(request.scraperTargetID, "/members"), request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteScrapersIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.deleteScrapersIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scrapers/".concat(request.scraperTargetID, "/members/").concat(request.userID), request, requestOptions);
        };
        /**
         * List all owners of a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetScrapersIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapersIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers/".concat(request.scraperTargetID, "/owners"), request, requestOptions);
        };
        /**
         * Add an owner to a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostScrapersIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.postScrapersIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scrapers/".concat(request.scraperTargetID, "/owners"), request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a scraper target.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteScrapersIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.deleteScrapersIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scrapers/".concat(request.scraperTargetID, "/owners/").concat(request.userID), request, requestOptions);
        };
        return ScrapersAPI;
    }());

    /**
     * Scripts API
     */
    var ScriptsAPI = /** @class */ (function () {
        /**
         * Creates ScriptsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ScriptsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List scripts.
         * See {@link https://docs.influxdata.com/influxdb/cloud/api/#operation/GetScripts }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScriptsAPI.prototype.getScripts = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scripts".concat(this.base.queryString(request, ['limit', 'offset'])), request, requestOptions);
        };
        /**
         * Create a script.
         * See {@link https://docs.influxdata.com/influxdb/cloud/api/#operation/PostScripts }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScriptsAPI.prototype.postScripts = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scripts", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a script.
         * See {@link https://docs.influxdata.com/influxdb/cloud/api/#operation/GetScriptsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScriptsAPI.prototype.getScriptsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scripts/".concat(request.scriptID), request, requestOptions);
        };
        /**
         * Update a script.
         * See {@link https://docs.influxdata.com/influxdb/cloud/api/#operation/PatchScriptsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScriptsAPI.prototype.patchScriptsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/scripts/".concat(request.scriptID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a script.
         * See {@link https://docs.influxdata.com/influxdb/cloud/api/#operation/DeleteScriptsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScriptsAPI.prototype.deleteScriptsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scripts/".concat(request.scriptID), request, requestOptions);
        };
        /**
         * Invoke a script.
         * See {@link https://docs.influxdata.com/influxdb/cloud/api/#operation/PostScriptsIDInvoke }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScriptsAPI.prototype.postScriptsIDInvoke = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scripts/".concat(request.scriptID, "/invoke"), request, requestOptions, 'application/json');
        };
        return ScriptsAPI;
    }());

    /**
     * Setup API
     */
    var SetupAPI = /** @class */ (function () {
        /**
         * Creates SetupAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function SetupAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Check if database has default user, org, bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetSetup }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SetupAPI.prototype.getSetup = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/setup", request, requestOptions);
        };
        /**
         * Set up initial user, org and bucket.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostSetup }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SetupAPI.prototype.postSetup = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/setup", request, requestOptions, 'application/json');
        };
        return SetupAPI;
    }());

    /**
     * Signin API
     */
    var SigninAPI = /** @class */ (function () {
        /**
         * Creates SigninAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function SigninAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Create a user session.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostSignin }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SigninAPI.prototype.postSignin = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/signin", request, requestOptions);
        };
        return SigninAPI;
    }());

    /**
     * Signout API
     */
    var SignoutAPI = /** @class */ (function () {
        /**
         * Creates SignoutAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function SignoutAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Expire the current UI session.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostSignout }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SignoutAPI.prototype.postSignout = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/signout", request, requestOptions);
        };
        return SignoutAPI;
    }());

    /**
     * Sources API
     */
    var SourcesAPI = /** @class */ (function () {
        /**
         * Creates SourcesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function SourcesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all sources.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetSources }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.getSources = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/sources".concat(this.base.queryString(request, ['org'])), request, requestOptions);
        };
        /**
         * Create a source.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostSources }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.postSources = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/sources", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a source.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetSourcesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.getSourcesID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/sources/".concat(request.sourceID), request, requestOptions);
        };
        /**
         * Update a Source.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchSourcesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.patchSourcesID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/sources/".concat(request.sourceID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a source.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteSourcesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.deleteSourcesID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/sources/".concat(request.sourceID), request, requestOptions);
        };
        /**
         * Get the health of a source.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetSourcesIDHealth }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.getSourcesIDHealth = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/sources/".concat(request.sourceID, "/health"), request, requestOptions);
        };
        /**
         * Get buckets in a source.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetSourcesIDBuckets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.getSourcesIDBuckets = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/sources/".concat(request.sourceID, "/buckets").concat(this.base.queryString(request, ['org'])), request, requestOptions);
        };
        return SourcesAPI;
    }());

    /**
     * Stacks API
     */
    var StacksAPI = /** @class */ (function () {
        /**
         * Creates StacksAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function StacksAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List installed templates.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/ListStacks }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.listStacks = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/stacks".concat(this.base.queryString(request, [
                'orgID',
                'name',
                'stackID',
            ])), request, requestOptions);
        };
        /**
         * Create a new stack.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/CreateStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.createStack = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/stacks", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a stack.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/ReadStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.readStack = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/stacks/".concat(request.stack_id), request, requestOptions);
        };
        /**
         * Update a stack.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/UpdateStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.updateStack = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/stacks/".concat(request.stack_id), request, requestOptions, 'application/json');
        };
        /**
         * Delete a stack and associated resources.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.deleteStack = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/stacks/".concat(request.stack_id).concat(this.base.queryString(request, [
                'orgID',
            ])), request, requestOptions);
        };
        /**
         * Uninstall a stack.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/UninstallStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.uninstallStack = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/stacks/".concat(request.stack_id, "/uninstall"), request, requestOptions);
        };
        return StacksAPI;
    }());

    /**
     * Tasks API
     */
    var TasksAPI = /** @class */ (function () {
        /**
         * Creates TasksAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function TasksAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Retrieve a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/".concat(request.taskID), request, requestOptions);
        };
        /**
         * Update a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchTasksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.patchTasksID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/tasks/".concat(request.taskID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTasksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/".concat(request.taskID), request, requestOptions);
        };
        /**
         * List runs for a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasksIDRuns }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDRuns = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/".concat(request.taskID, "/runs").concat(this.base.queryString(request, [
                'after',
                'limit',
                'afterTime',
                'beforeTime',
            ])), request, requestOptions);
        };
        /**
         * Manually start a task run, overriding the current schedule.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTasksIDRuns }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDRuns = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/".concat(request.taskID, "/runs"), request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a single run for a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasksIDRunsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDRunsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/".concat(request.taskID, "/runs/").concat(request.runID), request, requestOptions);
        };
        /**
         * Cancel a running task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTasksIDRunsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksIDRunsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/".concat(request.taskID, "/runs/").concat(request.runID), request, requestOptions);
        };
        /**
         * Retry a task run.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTasksIDRunsIDRetry }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDRunsIDRetry = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/".concat(request.taskID, "/runs/").concat(request.runID, "/retry"), request, requestOptions, 'application/json; charset=utf-8');
        };
        /**
         * Retrieve all logs for a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasksIDLogs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDLogs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/".concat(request.taskID, "/logs"), request, requestOptions);
        };
        /**
         * Retrieve all logs for a run.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasksIDRunsIDLogs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDRunsIDLogs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/".concat(request.taskID, "/runs/").concat(request.runID, "/logs"), request, requestOptions);
        };
        /**
         * List all labels for a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasksIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/".concat(request.taskID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTasksIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/".concat(request.taskID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTasksIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/".concat(request.taskID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        /**
         * List all task members.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasksIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/".concat(request.taskID, "/members"), request, requestOptions);
        };
        /**
         * Add a member to a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTasksIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/".concat(request.taskID, "/members"), request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTasksIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/".concat(request.taskID, "/members/").concat(request.userID), request, requestOptions);
        };
        /**
         * List all owners of a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasksIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/".concat(request.taskID, "/owners"), request, requestOptions);
        };
        /**
         * Add an owner to a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTasksIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/".concat(request.taskID, "/owners"), request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTasksIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/".concat(request.taskID, "/owners/").concat(request.userID), request, requestOptions);
        };
        /**
         * List all tasks.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTasks }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasks = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks".concat(this.base.queryString(request, [
                'name',
                'after',
                'user',
                'org',
                'orgID',
                'status',
                'limit',
                'type',
            ])), request, requestOptions);
        };
        /**
         * Create a new task.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTasks }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasks = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks", request, requestOptions, 'application/json');
        };
        return TasksAPI;
    }());

    /**
     * Telegraf API
     */
    var TelegrafAPI = /** @class */ (function () {
        /**
         * Creates TelegrafAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function TelegrafAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all Telegraf plugins.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTelegrafPlugins }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafAPI.prototype.getTelegrafPlugins = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegraf/plugins".concat(this.base.queryString(request, ['type'])), request, requestOptions);
        };
        return TelegrafAPI;
    }());

    /**
     * Telegrafs API
     */
    var TelegrafsAPI = /** @class */ (function () {
        /**
         * Creates TelegrafsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function TelegrafsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all Telegraf configurations.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTelegrafs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs".concat(this.base.queryString(request, ['orgID'])), request, requestOptions);
        };
        /**
         * Create a Telegraf configuration.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTelegrafs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.postTelegrafs = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/telegrafs", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a Telegraf configuration.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTelegrafsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs/".concat(request.telegrafID), request, requestOptions);
        };
        /**
         * Update a Telegraf configuration.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PutTelegrafsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.putTelegrafsID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/telegrafs/".concat(request.telegrafID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a Telegraf configuration.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTelegrafsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.deleteTelegrafsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/telegrafs/".concat(request.telegrafID), request, requestOptions);
        };
        /**
         * List all labels for a Telegraf config.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTelegrafsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafsIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs/".concat(request.telegrafID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a Telegraf config.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTelegrafsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.postTelegrafsIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/telegrafs/".concat(request.telegrafID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a Telegraf config.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTelegrafsIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.deleteTelegrafsIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/telegrafs/".concat(request.telegrafID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        /**
         * List all users with member privileges for a Telegraf config.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTelegrafsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafsIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs/".concat(request.telegrafID, "/members"), request, requestOptions);
        };
        /**
         * Add a member to a Telegraf config.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTelegrafsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.postTelegrafsIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/telegrafs/".concat(request.telegrafID, "/members"), request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a Telegraf config.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTelegrafsIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.deleteTelegrafsIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/telegrafs/".concat(request.telegrafID, "/members/").concat(request.userID), request, requestOptions);
        };
        /**
         * List all owners of a Telegraf configuration.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetTelegrafsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafsIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs/".concat(request.telegrafID, "/owners"), request, requestOptions);
        };
        /**
         * Add an owner to a Telegraf configuration.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostTelegrafsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.postTelegrafsIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/telegrafs/".concat(request.telegrafID, "/owners"), request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a Telegraf config.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteTelegrafsIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.deleteTelegrafsIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/telegrafs/".concat(request.telegrafID, "/owners/").concat(request.userID), request, requestOptions);
        };
        return TelegrafsAPI;
    }());

    /**
     * Templates API
     */
    var TemplatesAPI = /** @class */ (function () {
        /**
         * Creates TemplatesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function TemplatesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Apply or dry-run a template.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/ApplyTemplate }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TemplatesAPI.prototype.applyTemplate = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/templates/apply", request, requestOptions, 'application/json');
        };
        /**
         * Export a new template.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/ExportTemplate }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TemplatesAPI.prototype.exportTemplate = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/templates/export", request, requestOptions, 'application/json');
        };
        return TemplatesAPI;
    }());

    /**
     * Users API
     */
    var UsersAPI = /** @class */ (function () {
        /**
         * Creates UsersAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function UsersAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Update a password.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostUsersIDPassword }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.postUsersIDPassword = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/users/".concat(request.userID, "/password"), request, requestOptions, 'application/json');
        };
        /**
         * List all users.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetUsers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.getUsers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/users".concat(this.base.queryString(request, [
                'offset',
                'limit',
                'after',
                'name',
                'id',
            ])), request, requestOptions);
        };
        /**
         * Create a user.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostUsers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.postUsers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/users", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a user.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetUsersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.getUsersID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/users/".concat(request.userID), request, requestOptions);
        };
        /**
         * Update a user.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchUsersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.patchUsersID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/users/".concat(request.userID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a user.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteUsersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.deleteUsersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/users/".concat(request.userID), request, requestOptions);
        };
        return UsersAPI;
    }());

    /**
     * Variables API
     */
    var VariablesAPI = /** @class */ (function () {
        /**
         * Creates VariablesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function VariablesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all labels for a variable.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetVariablesIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.getVariablesIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/variables/".concat(request.variableID, "/labels"), request, requestOptions);
        };
        /**
         * Add a label to a variable.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostVariablesIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.postVariablesIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/variables/".concat(request.variableID, "/labels"), request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a variable.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteVariablesIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.deleteVariablesIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/variables/".concat(request.variableID, "/labels/").concat(request.labelID), request, requestOptions);
        };
        /**
         * List all variables.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetVariables }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.getVariables = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/variables".concat(this.base.queryString(request, ['org', 'orgID'])), request, requestOptions);
        };
        /**
         * Create a variable.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostVariables }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.postVariables = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/variables", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a variable.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/GetVariablesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.getVariablesID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/variables/".concat(request.variableID), request, requestOptions);
        };
        /**
         * Replace a variable.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PutVariablesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.putVariablesID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/variables/".concat(request.variableID), request, requestOptions, 'application/json');
        };
        /**
         * Update a variable.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PatchVariablesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.patchVariablesID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/variables/".concat(request.variableID), request, requestOptions, 'application/json');
        };
        /**
         * Delete a variable.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/DeleteVariablesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.deleteVariablesID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/variables/".concat(request.variableID), request, requestOptions);
        };
        return VariablesAPI;
    }());

    /**
     * Write API
     */
    var WriteAPI = /** @class */ (function () {
        /**
         * Creates WriteAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function WriteAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Write data.
         * See {@link https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostWrite }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        WriteAPI.prototype.postWrite = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/write".concat(this.base.queryString(request, [
                'org',
                'orgID',
                'bucket',
                'precision',
            ])), request, requestOptions, 'text/plain');
        };
        return WriteAPI;
    }());

    /**
     * FluxScriptInvocationAPI executes flux 'API invokable script' and parses the result CSV annotated data.
     * See https://docs.influxdata.com/influxdb/cloud/api-guide/api-invokable-scripts/ .
     */
    var FluxScriptInvocationAPI = /** @class */ (function () {
        /**
         * Creates FluxScriptInvocationAPI with the supplied InfluxDB instance and a particular script identifier.
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         * @param options - script execution options
         */
        function FluxScriptInvocationAPI(influxDB, options) {
            this.transport = influxDB.transport;
            this.processCSVResponse = influxDB.processCSVResponse;
            this.options = __assign({}, options);
        }
        /**
         * Invoke returns a parsed response data stream that executes
         * the supplied script when asked for data.
         * @param scriptID - script identifier
         * @param params  - script parameters
         * @returns response with various methods to process data from the returned annotated
         * CSV response data stream
         */
        FluxScriptInvocationAPI.prototype.invoke = function (scriptID, params) {
            return this.processCSVResponse(this.createExecutor(scriptID, params));
        };
        FluxScriptInvocationAPI.prototype.createExecutor = function (scriptID, params) {
            var _this = this;
            var _a = this.options, gzip = _a.gzip, headers = _a.headers;
            return function (consumer) {
                _this.transport.send("/api/v2/scripts/".concat(scriptID, "/invoke"), JSON.stringify({
                    params: __assign({}, params),
                }), {
                    method: 'POST',
                    headers: __assign({ 'content-type': 'application/json; encoding=utf-8', 'accept-encoding': gzip ? 'gzip' : 'identity' }, headers),
                }, consumer);
            };
        };
        return FluxScriptInvocationAPI;
    }());

    exports.AuthorizationsAPI = AuthorizationsAPI;
    exports.BackupAPI = BackupAPI;
    exports.BucketsAPI = BucketsAPI;
    exports.ChecksAPI = ChecksAPI;
    exports.ConfigAPI = ConfigAPI;
    exports.DashboardsAPI = DashboardsAPI;
    exports.DbrpsAPI = DbrpsAPI;
    exports.DebugAPI = DebugAPI;
    exports.DeleteAPI = DeleteAPI;
    exports.FlagsAPI = FlagsAPI;
    exports.FluxScriptInvocationAPI = FluxScriptInvocationAPI;
    exports.HealthAPI = HealthAPI;
    exports.LabelsAPI = LabelsAPI;
    exports.LegacyAPI = LegacyAPI;
    exports.MeAPI = MeAPI;
    exports.MetricsAPI = MetricsAPI;
    exports.NotificationEndpointsAPI = NotificationEndpointsAPI;
    exports.NotificationRulesAPI = NotificationRulesAPI;
    exports.OrgsAPI = OrgsAPI;
    exports.PingAPI = PingAPI;
    exports.QueryAPI = QueryAPI;
    exports.ReadyAPI = ReadyAPI;
    exports.RemotesAPI = RemotesAPI;
    exports.ReplicationsAPI = ReplicationsAPI;
    exports.ResourcesAPI = ResourcesAPI;
    exports.RestoreAPI = RestoreAPI;
    exports.RootAPI = RootAPI;
    exports.ScrapersAPI = ScrapersAPI;
    exports.ScriptsAPI = ScriptsAPI;
    exports.SetupAPI = SetupAPI;
    exports.SigninAPI = SigninAPI;
    exports.SignoutAPI = SignoutAPI;
    exports.SourcesAPI = SourcesAPI;
    exports.StacksAPI = StacksAPI;
    exports.TasksAPI = TasksAPI;
    exports.TelegrafAPI = TelegrafAPI;
    exports.TelegrafsAPI = TelegrafsAPI;
    exports.TemplatesAPI = TemplatesAPI;
    exports.UsersAPI = UsersAPI;
    exports.VariablesAPI = VariablesAPI;
    exports.WriteAPI = WriteAPI;

    Object.defineProperty(exports, '__esModule', { value: true });

    return exports;

})({});
//# sourceMappingURL=influxdbApis.js.map
